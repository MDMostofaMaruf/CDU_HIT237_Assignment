from django import forms
from .models import *


#ModelForm from imported from model.py
class SongForm(forms.ModelForm):
    class Meta:
        model=Song
        fields=['title', 'writer','singer', 'production', 'rating', 'released_date']


class SingerForm(forms.ModelForm):
    class Meta:
        model=Singer
        exclude=  []

class ProductionForm(forms.ModelForm):
    class Meta:
        model=Production
        exclude=  []
