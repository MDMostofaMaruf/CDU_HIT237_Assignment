from django.shortcuts import render
from django.http import HttpResponseRedirect
from django.urls import reverse

from django.shortcuts import render, get_object_or_404


from app_assesment.models import *
from app_assesment.forms import *

# Create your views here.

#Adding song by form
def Add_song(request):
    page_data={'my_form': SongForm(),}
    return render (request, 'add_song_form.html', page_data)


#Submit and save
def Add_song_submit(request):
    if request.method != 'POST':
        page_data={
        'my_form':SongForm(),
        }

    else:


        form = SongForm (request.POST)
        if form.is_valid() !=True:
            page_data={'my_form': form }


        else:
            data = form.cleaned_data
            new_auth_object=form.save()
            return HttpResponseRedirect(reverse('Display_add'))


    return render (request, 'add_song_form.html', page_data)






#Adding Singers by form
def Add_singer(request):
    page_data={'my_form': SingerForm(),}
    return render (request, 'add_singers_form.html', page_data)


#Submit and save
def Add_singer_submit(request):
    if request.method != 'POST':
        page_data={
        'my_form':SingerForm(),
        }

    else:


        form = SingerForm (request.POST)
        if form.is_valid() !=True:
            page_data={'my_form': form }


        else:
            data = form.cleaned_data
            new_auth_object=form.save()
            return HttpResponseRedirect(reverse('Display_add'))


    return render (request, 'add_singers_form.html', page_data)





#Adding productions by form
def Add_production(request):
    page_data={'my_form': ProductionForm(),}
    return render (request, 'add_production_form.html', page_data)


#Submit and save
def Add_production_submit(request):
    if request.method != 'POST':
        page_data={
        'my_form':ProductionForm(),
        }

    else:


        form = ProductionForm (request.POST)
        if form.is_valid() !=True:
            page_data={'my_form': form }


        else:
            data = form.cleaned_data
            new_auth_object=form.save()
            return HttpResponseRedirect(reverse('Display_add'))


    return render (request, 'add_production_form.html', page_data)

#Display after adding data
def Display_add(request):
    return render (request,'add_data.html')

#Data adding finish-------------------------------------------------------------------------------------------------------------------




#Data UPDATE-----------


#Update song
def Update_song(request,id):
    song=Song.objects.get(pk=id)
    if request.method=='POST':
        form=SongForm(request.POST,instance=song)
        if form.is_valid () !=True:
            page_data={'my_form':form}
        else:
            form.save()
            return HttpResponseRedirect(reverse('All_song'))
    else:
        form=SongForm(instance=song)
        page_data={'my_form':form}
    return render (request, 'update_song.html', page_data)

#Update Singer
def Update_singer(request,id):
    singer=Singer.objects.get(pk=id)
    if request.method=='POST':
        form=SingerForm(request.POST,instance=singer)
        if form.is_valid () !=True:
            page_data={'my_form':form}
        else:
            form.save()
            return HttpResponseRedirect(reverse('All_singer'))
    else:
        form=SingerForm(instance=singer)
        page_data={'my_form':form}
    return render (request, 'Update_singer.html', page_data)


#Update productions
def Update_production(request,id):
    production=Production.objects.get(pk=id)
    if request.method=='POST':
        form=ProductionForm(request.POST,instance=production)
        if form.is_valid () !=True:
            page_data={'my_form':form}
        else:
            form.save()
            return HttpResponseRedirect(reverse('All_production'))
    else:
        form=ProductionForm(instance=production)
        page_data={'my_form':form}
    return render (request, 'Update_singer.html', page_data)




#Deleting data
def Delete_song(request,id):
    song = Song.objects.get(pk=id)
    song.delete()
    return HttpResponseRedirect(reverse('Display_delete'))

def Delete_singer(request,id):
    singer = Singer.objects.get(pk=id)
    singer.delete()
    return HttpResponseRedirect(reverse('Display_delete'))


def Delete_production(request,id):
    production = Production.objects.get(pk=id)
    singer.delete()
    return HttpResponseRedirect(reverse('Display_delete'))







def Display_delete(request):
    return render (request,'delete.html')









#Viewing HomePage and other pages:
def Home(request):
    page_data={}
    return render(request, 'index.html',page_data)

def All_song(request):
    results = Song.objects.all()
    page_data = {'list_songs': results}
    return render(request,
                  'all_songs.html',
                  page_data)


def All_singer(request):
    results = Singer.objects.all()
    page_data = {'list_singer': results}
    return render(request,
                  'all_singers.html',
                  page_data)

def All_production(request):
    results = Production.objects.all()
    page_data = {'list_production': results}
    return render(request,
                  'all_production.html',
                  page_data)
