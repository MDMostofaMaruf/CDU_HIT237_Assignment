from django.db import models

# Create your models here.


class Singer(models.Model):
    firstname=models.CharField(max_length=15)
    lastname=models.CharField(max_length=15)
    email=models.EmailField()


    def __str__(self):
        return u'%s %s' % (self.firstname, self.lastname)




class Production(models.Model):
    name = models.CharField(max_length=30)
    address = models.CharField(max_length=50)
    city = models.CharField(max_length=60)
    state_province = models.CharField(max_length=30)
    country = models.CharField(max_length=50)
    website = models.URLField()

    def __str__(self):
        return self.name




#Primary Entity
class Song(models.Model):
    title=models.CharField(max_length=30)
    writer=models.CharField(max_length=30)
    singer=models.ForeignKey(Singer,on_delete=models.CASCADE)
    production=models.ForeignKey(Production,on_delete=models.CASCADE)
    rating=models.DecimalField(max_digits=10,decimal_places=3)
    released_date=models.DateTimeField(auto_now=False)

    def __str__(self):
        return str(self.id) + " : " + self.title
