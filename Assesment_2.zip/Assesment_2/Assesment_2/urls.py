"""Assesment_2 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf.urls import url
from app_assesment import views

urlpatterns = [
    path('admin/', admin.site.urls),


    #Song Update data
    path('r^<int:id>$', views.Update_song,name='Update_song'),
    path('update/<int:id>/', views.Update_singer,name='Update_singer'),
    path('updateP/<int:id>/', views.Update_production,name='Update_production'),


    #Delete data
    path('delete/<int:id>/',views.Delete_song,name='Delete_song'),
    path('delete/<int:id>/',views.Delete_singer,name='Delete_singer'),
    path('delete/<int:id>/',views.Delete_production,name='Delete_production'),



    #HomePage URL
    url(r'^$', views.Home, name='Home'),
    #Other pages URL
    path('All_song/', views.All_song, name='All_song'),
    path('All_singer/', views.All_singer, name='All_singer'),
    path('All_production/', views.All_production, name='All_production'),



    #Insert song url
    url(r'^Add_song$', views.Add_song, name='Add_song'),
    url(r'^Add_song_submit$', views.Add_song_submit, name='Add_song_submit'),

    #Insert singer url
    url(r'^Add_singer$', views.Add_singer, name='Add_singer'),
    url(r'^Add_singer_submit$', views.Add_singer_submit, name='Add_singer_submit'),


    #Insert production url
    url(r'^Add_production$', views.Add_production, name='Add_production'),
    url(r'^Add_production_submit$', views.Add_production_submit, name='Add_production_submit'),


    #Display deleted
    url(r'^Display_delete$', views.Display_delete, name='Display_delete'),
    url(r'^Display_add$', views.Display_add, name='Display_add'),



]
