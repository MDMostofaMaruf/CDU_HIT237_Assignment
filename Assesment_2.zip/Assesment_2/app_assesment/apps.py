from django.apps import AppConfig


class AppAssesmentConfig(AppConfig):
    name = 'app_assesment'
