from django.contrib import admin

# Register your models here.

from django.contrib import admin
from app_assesment.models import Singer
from app_assesment.models import Production
from app_assesment.models import Song

# Register your models here.

admin.site.register(Singer)
admin.site.register(Song)
admin.site.register(Production)
